<?php
  header("refresh:5;url=login.php");
?>
<html>
  <head>
    <meta charset="utf-8">
    <title>Creation Success</title>
    <link rel="stylesheet" href="styles/styles.css">
  </head>
  <body>
    <h1>Account Created Successfully</h1>
    <p id = "centerMessage">
      You will be redirected automatically in 5 seconds
    </p>
  </body>
</html>
