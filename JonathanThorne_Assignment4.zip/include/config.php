<?php
   define('servername', 'sql2.njit.edu');
   define('username', 'jgt8');
   define('password', '4KdfXPr7r');
   define('dbname', 'jgt8');
   $db = mysqli_connect(servername,username,password,dbname);
?>
